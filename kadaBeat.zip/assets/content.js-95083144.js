/* empty css               */let Te=10,me=0;function Ie(){return new Promise((a,p)=>{function s(){const e=document.querySelector("video"),u=document.querySelector("ytd-app");if(e&&u)a();else{if(me++,me>=Te){p("YouTube UI failed to load");return}setTimeout(s,1e3)}}s()})}class A{static async trackEvent(p,s){try{await chrome.runtime.sendMessage({type:"TRACK_EVENT",eventType:p,eventData:{...s,url:window.location.href,videoId:A.getYouTubeVideoId()}})}catch(e){console.error("Error sending analytics:",e)}}static getYouTubeVideoId(){return new URLSearchParams(window.location.href.split("?")[1]).get("v")}}function n(a,p={},s=""){const e=document.createElement(a);return Object.entries(p).forEach(([u,x])=>{e.setAttribute(u,x)}),s&&(e.textContent=s),e}function qe(){const a=n("div",{class:"top-contributors"}),p=n("div",{class:"top-contributors-header"}),s=n("div",{class:"top-contributors-title"},"🏆 Top Contributors");p.appendChild(s);const e=n("div",{class:"contributor-list"});for(let C=0;C<5;C++){const $=n("div",{class:"contributor-skeleton"});e.appendChild($)}let u=1,x=!1,F=!0;function P(C){for(;C.firstChild;)C.removeChild(C.firstChild)}async function D(C=!1){if(!(x||!F)){x=!0;try{const E=await(await fetch(`https://visualizer.pockethost.io/api/collections/topContributor/records?page=${u}&perPage=2&sort=-donatedAmount`)).json();if(C&&P(e),E.items.forEach((g,v)=>{const H=(u-1)*2+v+1,f=n("div",{class:"contributor-item"}),q=n("div",{class:"contributor-info-wrapper"});let z="";H===1?z="rank-gold":H===2?z="rank-silver":H===3&&(z="rank-bronze");const m=n("div",{class:`contributor-rank ${z}`},H.toString()),T=n("div",{class:"contributor-info"}),j=n("div",{class:"contributor-name"},g.name),V=n("div",{class:"contributor-amount"},`Donated: NPR ${g.donatedAmount}`);T.appendChild(j),T.appendChild(V),q.appendChild(m),q.appendChild(T);const N=n("div",{class:"badge-container"});if(g.top){const U=n("div",{class:`contributor-badge ${g.top.toLowerCase()}`},g.top);N.appendChild(U)}if(g.donatedAmount>=5e3){const U=n("div",{class:"contributor-badge gold"},"Gold");N.appendChild(U)}else if(g.donatedAmount>=2500){const U=n("div",{class:"contributor-badge silver"},"Silver");N.appendChild(U)}f.appendChild(q),f.appendChild(N),e.appendChild(f)}),F=u<E.totalPages,u++,x=!1,F){const g=a.querySelector(".load-more");g&&g.remove();const v=n("button",{class:"load-more"},"Load More");v.addEventListener("click",()=>{v.remove(),D()}),a.appendChild(v)}}catch($){console.error("Error loading contributors:",$);const E=n("div",{style:"color: #ff4444; text-align: center; padding: 10px;"},"Failed to load contributors");C&&P(e),e.appendChild(E),x=!1}}}return D(!0),a.appendChild(p),a.appendChild(e),a}function Be(){const a=n("div",{class:"qr-modal"}),p=n("div",{class:"qr-container"}),s=n("div",{class:"qr-cover-wrapper"}),e=n("div",{class:"qr-cover skeleton"}),u=n("img",{class:"qr-cover-image",src:"https://visualizer.pockethost.io/api/files/j8d2zuan0helf7z/COVER_IMAGE_ID/cover.jpg",alt:"Cover"});u.style.opacity="0",u.addEventListener("load",()=>{e.classList.remove("skeleton"),u.style.opacity="1"}),u.addEventListener("error",()=>{e.classList.remove("skeleton"),e.style.backgroundColor="rgba(145, 65, 255, 0.1)",u.style.display="none"}),e.appendChild(u),s.appendChild(e);const x=n("div",{class:"qr-close"},"×"),F=n("div",{class:"qr-header"}),P=n("div",{class:"qr-title skeleton skeleton-text"}),D=n("div",{class:"qr-subtitle skeleton skeleton-text skeleton-text-sm"}),C=n("div",{class:"qr-image-container"}),$=n("div",{class:"skeleton skeleton-image"}),E=n("img",{class:"qr-image",alt:"Payment QR Code",style:"display: none;"});C.appendChild($),C.appendChild(E);const g=n("div",{class:"qr-payment-options"});for(let f=0;f<2;f++){const q=n("div",{class:"skeleton skeleton-button"});g.appendChild(q)}fetch("https://visualizer.pockethost.io/api/collections/payment/records").then(f=>f.json()).then(f=>{if(P.textContent="Scan to Pay",P.classList.remove("skeleton","skeleton-text"),D.textContent="Support the development of this visualizer",D.classList.remove("skeleton","skeleton-text","skeleton-text-sm"),Q(g),f.items.forEach(q=>{const z=n("div",{class:"qr-payment-option","data-qr":`https://visualizer.pockethost.io/api/files/${q.collectionId}/${q.id}/${q.qr}`},q.name);z.addEventListener("click",()=>{document.querySelectorAll(".qr-payment-option").forEach(m=>{m.classList.remove("active")}),z.classList.add("active"),$.style.display="block",E.style.display="none",E.src=z.dataset.qr}),g.appendChild(z)}),f.items.length>0){const q=g.firstElementChild;q.classList.add("active"),E.src=q.dataset.qr}}).catch(f=>{console.error("Error fetching payment options:",f),Q(g);const q=n("div",{class:"qr-error"},"Failed to load payment options. Please try again later.");g.appendChild(q)}),E.addEventListener("load",()=>{$.style.display="none",E.style.display="block"}),E.addEventListener("error",()=>{$.style.display="none",Q(C);const f=n("div",{style:"color: #ff4444;"},"Failed to load QR code image");C.appendChild(f)});const v=n("div",{class:"qr-info"},"Scan with your preferred payment app to support the developer");p.appendChild(s),p.appendChild(x),F.appendChild(P),F.appendChild(D),p.appendChild(F),p.appendChild(C),p.appendChild(g),p.appendChild(v),a.appendChild(p),x.addEventListener("click",()=>{a.classList.remove("active"),setTimeout(()=>a.remove(),300)}),a.addEventListener("click",f=>{f.target===a&&(a.classList.remove("active"),setTimeout(()=>a.remove(),300))});const H=f=>{f.key==="Escape"&&(a.classList.remove("active"),setTimeout(()=>{a.remove(),document.removeEventListener("keydown",H)},300))};return document.addEventListener("keydown",H),a}function Q(a){for(;a.firstChild;)a.removeChild(a.firstChild)}function Me(){const a=n("div",{class:"developer-section"}),p=qe();a.appendChild(p);const s=n("div",{class:"support-section","data-animate":"true"}),e=n("div",{class:"developer-info skeleton"}),u=n("div",{class:"developer-icon"},"👨‍💻"),x=n("div",{class:"developer-details"}),F=n("div",{class:"developer-name skeleton"}),P=n("div",{class:"developer-title skeleton"}),D=n("div",{class:"developer-description skeleton"});x.appendChild(F),x.appendChild(P),x.appendChild(D);const C=n("div",{class:"social-container"}),$=n("div",{class:"social-links-toggle",title:"Social Links"},"🔗"),E=n("div",{class:"social-links-dropdown"});for(let m=0;m<4;m++){const T=n("div",{class:"social-link skeleton"});E.appendChild(T)}const g=n("div",{class:"support-content"}),v=n("div",{class:"support-title"},"✨ Support the Developer"),H=n("div",{class:"support-description"},"Your contribution helps keep this project alive and enables new features! 🎵"),f=n("div",{class:"payment-buttons"}),q=n("div",{class:"payment-button",id:"esewa-pay"},"💳 eSewa: 9807038534"),z=n("div",{class:"payment-button",id:"qr-pay"},"📱 Scan QR");return fetch("https://visualizer.pockethost.io/api/collections/author/records").then(m=>m.json()).then(m=>{if(m.items&&m.items.length>0){const T=m.items[0];e.classList.remove("skeleton");const j=n("div",{class:"developer-name"},T.name),V=n("div",{class:"developer-title"},T.developer_title);H.innerText=T.description,Q(x),x.appendChild(j),x.appendChild(V);try{const N=T.socialLinks;Q(E),N.forEach(U=>{const G=n("div",{class:"social-link"}),se=n("span",{class:"social-icon"},U.icon),J=n("span",{class:"social-text"},U.text);G.appendChild(se),G.appendChild(J),G.addEventListener("click",ie=>{ie.stopPropagation(),window.open(U.url,"_blank")}),E.appendChild(G)})}catch(N){console.error("Error parsing social links:",N);const U=n("div",{class:"social-link",style:"color: #ff4444;"},"Failed to load social links");Q(E),E.appendChild(U)}}}).catch(m=>{console.error("Error fetching author data:",m);const T=n("div",{class:"developer-name",style:"color: #ff4444;"},"Failed to load developer info");Q(x),x.appendChild(T)}),$.addEventListener("click",m=>{m.stopPropagation(),E.classList.toggle("active")}),document.addEventListener("click",m=>{!m.target.closest(".social-links-dropdown")&&!m.target.closest(".social-links-toggle")&&E.classList.remove("active")}),q.addEventListener("click",m=>{m.stopPropagation(),A.trackEvent("PAYMENT_CLICK",{method:"esewa"}),navigator.clipboard.writeText("9807038534").then(()=>{alert("eSewa number copied to clipboard: 9807038534")})}),z.addEventListener("click",m=>{m.stopPropagation(),A.trackEvent("PAYMENT_CLICK",{method:"qr"});const T=Be();document.body.appendChild(T),setTimeout(()=>T.classList.add("active"),10)}),e.appendChild(u),e.appendChild(x),C.appendChild($),C.appendChild(E),f.appendChild(q),f.appendChild(z),g.appendChild(v),g.appendChild(H),g.appendChild(f),s.appendChild(e),s.appendChild(C),s.appendChild(g),a.appendChild(s),a}class Re{constructor(p=1.15,s=30){this.sensitivity=p,this.minThreshold=s,this.lastBeatTime=0,this.lastEnergy=0}detectBeat(p){let s=0;for(let u=0;u<p.length;u++)s+=p[u]*p[u];s=s/p.length;const e=s>this.lastEnergy*this.sensitivity&&s>this.minThreshold;if(this.lastEnergy=s,e){const u=Date.now();if(u-this.lastBeatTime>100)return this.lastBeatTime=u,!0}return!1}}function Fe(){var fe;if(document.getElementById("sound-visualizer-container"))return;const a=n("div",{id:"toggle-ui"}),p=n("img",{src:"https://visualizer.pockethost.io/api/files/7tfk2haeqzw9o08/oreqjj8kxkpo9je/icon128_bHOdr44b0U.png",alt:"Toggle Visualizer",width:"32",height:"32"});a.appendChild(p),document.body.appendChild(a);const s=n("div",{id:"sound-visualizer-container"}),e=n("canvas",{id:"sound-visualizer",width:"320",height:"120"});s.appendChild(e);const u=n("select",{id:"visualizer-type"});["Bars","Circles","Waveform","Pixels","Spectrum","Starburst","Rain","sharingan","Particles","3D Spectrum","Energy Field"].forEach(o=>{const d=n("option",{value:o.toLowerCase()},o);u.appendChild(d)}),s.appendChild(u);const F=[{label:"Low",id:"low-slider",min:-20,max:20,value:0,frequency:60},{label:"Bass",id:"bass-slider",min:-20,max:20,value:0,frequency:200},{label:"Mid",id:"mid-slider",min:-20,max:20,value:0,frequency:1e3},{label:"High",id:"high-slider",min:-20,max:20,value:0,frequency:3e3},{label:"Treble",id:"treble-slider",min:-20,max:20,value:0,frequency:8e3}];F.forEach(o=>{const d=n("div",{class:"sound-control"}),y=n("label",{},o.label),B=n("input",{type:"range",id:o.id,min:o.min.toString(),max:o.max.toString(),value:o.value.toString()});d.appendChild(y),d.appendChild(B),s.appendChild(d)});const P=n("button",{class:"toggle-button",id:"toggle-dolby"},"Toggle Dolby Sound"),D=n("div",{class:"toggle-container"});D.appendChild(P),s.appendChild(D);const C=n("div",{class:"preset-container"});["Rock","Jazz","Pop","Classical","Metal","Hip-Hop"].forEach(o=>{const d=n("div",{class:"preset-option"},o);d.addEventListener("click",()=>{document.querySelectorAll(".preset-option").forEach(y=>{y.classList.remove("active")}),d.classList.add("active"),Le(o)}),C.appendChild(d)}),s.appendChild(C),s.appendChild(Me()),document.body.appendChild(s);const E=document.querySelector("video");if(!E){console.error("YouTube video element not found.");return}const g=new(window.AudioContext||window.webkitAudioContext),v=g.createAnalyser(),H=g.createMediaElementSource(E),f=g.createGain(),q=new Re,z=g.createStereoPanner(),m=g.createDynamicsCompressor();let T=H;const j=F.map(o=>{const d=g.createBiquadFilter();return d.type=o.label==="Low"||o.label==="Bass"?"lowshelf":"peaking",d.frequency.value=o.frequency,d.gain.value=0,d});j.forEach(o=>{T.connect(o),T=o}),T.connect(f).connect(v).connect(g.destination);let V=!1;P.addEventListener("click",()=>{V=!V,P.classList.toggle("active"),A.trackEvent("DOLBY_TOGGLE",{enabled:!V}),T.disconnect(),f.disconnect(),V?(T.connect(f).connect(z).connect(m).connect(v).connect(g.destination),z.pan.value=0,m.threshold.value=-12,m.knee.value=15,m.ratio.value=4,f.gain.value=1.05):(T.connect(f).connect(v).connect(g.destination),f.gain.value=1)});const N=n("div",{class:"video-enhancement"}),U=n("div",{class:"enhancement-title"},"🎬 Video Enhancement");N.appendChild(U);const G=n("div",{class:"video-filters"});[{label:"Brightness",id:"brightness",min:50,max:150,value:100},{label:"Contrast",id:"contrast",min:50,max:150,value:100},{label:"Saturation",id:"saturation",min:0,max:200,value:100},{label:"Hue",id:"hue",min:0,max:360,value:0},{label:"Blur",id:"blur",min:0,max:10,value:0},{label:"Sepia",id:"sepia",min:0,max:100,value:0}].forEach(o=>{const d=n("div",{class:"sound-control"}),y=n("label",{},o.label),B=n("input",{type:"range",id:o.id,min:o.min.toString(),max:o.max.toString(),value:o.value.toString()});B.addEventListener("input",()=>{re()}),d.appendChild(y),d.appendChild(B),G.appendChild(d)});const J=n("div",{class:"preset-container"}),ie={HDR:{brightness:110,contrast:120,saturation:130,hue:0,blur:0,sepia:0},Cinema:{brightness:95,contrast:115,saturation:110,hue:0,blur:0,sepia:20},Vivid:{brightness:105,contrast:125,saturation:140,hue:0,blur:0,sepia:0},Retro:{brightness:100,contrast:90,saturation:80,hue:0,blur:0,sepia:30},Noir:{brightness:90,contrast:120,saturation:70,hue:0,blur:0,sepia:100},Batman:{brightness:90,contrast:110,saturation:80,hue:0,blur:0,sepia:20},"Star Wars":{brightness:100,contrast:105,saturation:120,hue:20,blur:0,sepia:10},Matrix:{brightness:80,contrast:120,saturation:100,hue:90,blur:0,sepia:30},"Jurassic Park":{brightness:105,contrast:100,saturation:115,hue:60,blur:0,sepia:5},"Lord of the Rings":{brightness:100,contrast:110,saturation:105,hue:30,blur:0,sepia:15}};function re(){const o=document.querySelector("video");if(o){const d=document.getElementById("brightness").value,y=document.getElementById("contrast").value,B=document.getElementById("saturation").value,l=document.getElementById("hue").value,i=document.getElementById("blur").value,c=document.getElementById("sepia").value;A.trackEvent("VIDEO_FILTER_CHANGE",{brightness:document.getElementById("brightness").value,contrast:document.getElementById("contrast").value,saturation:document.getElementById("saturation").value,hue:document.getElementById("hue").value,blur:document.getElementById("blur").value,sepia:document.getElementById("sepia").value}),o.style.filter=`
      brightness(${d}%)
      contrast(${y}%)
      saturate(${B}%)
      hue-rotate(${l}deg)
      blur(${i}px)  
      sepia(${c}%)
    `}}function we(o){document.getElementById("brightness").value=o.brightness,document.getElementById("contrast").value=o.contrast,document.getElementById("saturation").value=o.saturation,document.getElementById("hue").value=o.hue,document.getElementById("blur").value=o.blur,document.getElementById("sepia").value=o.sepia,re()}Object.entries(ie).forEach(([o,d])=>{const y=n("button",{class:"preset-option"},o);y.addEventListener("click",()=>{document.querySelectorAll(".preset-option").forEach(B=>B.classList.remove("active")),y.classList.add("active"),we(d)}),J.appendChild(y)}),N.appendChild(G),N.appendChild(J),s.insertBefore(N,s.children[9]),a.addEventListener("click",()=>{s.classList.toggle("active")}),(fe=document.getElementById("esewa-pay"))==null||fe.addEventListener("click",()=>{alert("eSewa Payment: 9807038534")});const b=new Uint8Array(v.frequencyBinCount),t=e.getContext("2d"),L=v.frequencyBinCount;let ke=new Array(L).fill(0).map(()=>({y:0,speed:Math.random()*5+2}));function le(){const o={current:0,target:0,speed:.2};requestAnimationFrame(le);const d=document.getElementById("visualizer-type").value;v.getByteFrequencyData(b);const y=q.detectBeat(b);if(y?(t.fillStyle="rgba(255, 255, 255, 0.2)",t.fillRect(0,0,e.width,e.height)):t.clearRect(0,0,e.width,e.height),t.clearRect(0,0,e.width,e.height),y){e.classList.add("beat"),setTimeout(()=>e.classList.remove("beat"),100);const l=t.createRadialGradient(e.width/2,e.height/2,0,e.width/2,e.height/2,e.width/2);l.addColorStop(0,"rgba(145, 65, 255, 0.2)"),l.addColorStop(1,"rgba(145, 65, 255, 0)"),t.fillStyle=l,t.fillRect(0,0,e.width,e.height)}function B(){return y?o.target=1:o.target=0,o.current+=(o.target-o.current)*o.speed,o.current}if(d==="bars")v.getByteFrequencyData(b),b.forEach((l,i)=>{let c=l/2;const h=B();c*=1+h*.2,t.fillStyle="#9141FF",t.fillRect(i*3.2,e.height-c,2.6,c)});else if(d==="circles"){v.getByteFrequencyData(b);const l=e.height/4*(y?1.2:1),i=e.width/2,c=e.height/2,h=270;t.lineWidth=2,t.lineCap="round";for(let r=0;r<L;r++){const w=b[r]/255,M=r/L*Math.PI*2,I=l+w*l,S=Math.cos(M)*I+i,k=Math.sin(M)*I+c,R=t.createRadialGradient(S,k,0,S,k,w*20);R.addColorStop(0,`hsla(${h}, 100%, 50%, 1)`),R.addColorStop(1,`hsla(${h}, 100%, 50%, 0)`),t.strokeStyle=R,t.beginPath(),t.moveTo(i,c),t.lineTo(S,k),t.stroke()}t.fillStyle=`hsla(${h}, 100%, 50%, 0.1)`,t.beginPath(),t.arc(i,c,l*1.5,0,Math.PI*2),t.fill()}else if(d==="waveform"){v.getByteTimeDomainData(b),t.lineWidth=2,t.strokeStyle="hsl(270, 100%, 70%)",t.beginPath();const l=e.width/L;let i=0;for(let c=0;c<L;c++){const r=b[c]/128*(e.height/2);c===0?t.moveTo(i,r):t.lineTo(i,r),i+=l}t.lineTo(e.width,e.height/2),t.stroke(),t.lineWidth=1,t.strokeStyle="hsla(270, 100%, 70%, 0.4)",t.beginPath(),i=0;for(let c=0;c<L;c++){const r=b[c]/128*(e.height/2)+e.height/2;c===0?t.moveTo(i,r):t.lineTo(i,r),i+=l}t.lineTo(e.width,e.height),t.stroke()}else if(d==="pixels"){v.getByteFrequencyData(b);const l=4,i=1,c=Math.floor(e.width/(l+i)),h=Math.floor(L/c);for(let r=0;r<h;r++)for(let w=0;w<c;w++){const M=r*c+w,I=b[M]/255,S=M/L*360,k=w*(l+i),R=r*(l+i);t.fillStyle=`hsl(${S}, 100%, ${I*50}%)`,t.fillRect(k,R,l,l)}}else if(d==="spectrum"){v.getByteFrequencyData(b);const l=e.width/L;let i=0;for(let c=0;c<L;c++){const r=b[c]/255*e.height,w=c/L*360;t.fillStyle=`hsl(${w}, 100%, 50%)`,t.fillRect(i,e.height-r,l,r),i+=l}}else if(d==="starburst"){v.getByteFrequencyData(b);const l=e.width/2,i=e.height/2,c=Math.min(l,i),h=Math.PI*2/L;t.beginPath(),t.moveTo(l,i);for(let r=0;r<L;r++){const w=b[r]/255,M=r*h,I=c*w,S=l+Math.cos(M)*I,k=i+Math.sin(M)*I;t.lineTo(S,k)}t.closePath(),t.strokeStyle="hsl(270, 100%, 70%)",t.lineWidth=2,t.stroke()}else if(d==="rain"){v.getByteFrequencyData(b);const l=e.width/L;t.fillStyle="rgba(0, 0, 0, 0.1)",t.fillRect(0,0,e.width,e.height),t.strokeStyle="#9141FF",t.lineWidth=2;for(let i=0;i<L;i+=1){const c=b[i]/255,h=i*l+l/2,r=ke[i],w=c*e.height/25;r.y+=r.speed,r.y>e.height&&(r.y=0,r.speed=Math.random()*2+2),t.beginPath(),t.moveTo(h,r.y),t.lineTo(h,r.y-w),t.stroke()}if(Math.random()<.005){const i=Math.random()*e.width,c=Math.random()*e.height/2,h=Math.random()*e.width/3,r=Math.random()*e.height/3;t.fillStyle="rgba(255, 255, 255, 0.8)",t.fillRect(i,c,h,r),setTimeout(()=>{t.fillStyle="rgba(0, 0, 0, 0.1)",t.fillRect(i,c,h,r)},50)}}else if(d==="sharingan"){v.getByteFrequencyData(b);const l=e.width/2,i=e.height/2;t.fillStyle="rgba(0, 0, 0, 0.2)",t.fillRect(0,0,e.width,e.height);const c=Math.min(l,i)/4,h=Math.min(l,i)/1.2,r=Math.max(...b)/255,M=Date.now()*.002*Math.PI*.05;for(let k=1;k<=3;k++){const R=c+r*k*20;t.beginPath(),t.arc(l,i,R,0,Math.PI*2),t.strokeStyle=`rgba(255, 0, 0, ${.3+r/2})`,t.lineWidth=2,t.stroke()}const I=3;t.lineWidth=4,t.strokeStyle="rgba(255, 0, 0, 0.8)";for(let k=0;k<I;k++){const R=k/I*Math.PI*2+M,W=c*1.5+r*10,_=l+Math.cos(R)*W,oe=i+Math.sin(R)*W;t.beginPath(),t.arc(_,oe,10,0,Math.PI*2),t.fillStyle="rgba(0, 0, 0, 0.8)",t.fill(),t.beginPath(),t.arc(_,oe,6,0,Math.PI*2),t.fillStyle="rgba(255, 0, 0, 0.8)",t.fill()}const S=L/8;t.lineWidth=1;for(let k=0;k<S;k++){const R=b[k]/255,W=h*R,_=k/S*Math.PI*2+M*.2,oe=l+Math.cos(_)*W,Se=i+Math.sin(_)*W;t.strokeStyle=`rgba(255, 0, 0, ${R*.8})`,t.beginPath(),t.moveTo(l,i),t.lineTo(oe,Se),t.stroke()}}else if(d==="particles"){v.getByteFrequencyData(b),t.fillStyle="rgba(0, 0, 0, 0.1)",t.fillRect(0,0,e.width,e.height);const l=100;for(let i=0;i<l;i++){const c=b[i%L],h=c/255,r=i/l*Math.PI*2,w=h*Math.min(e.width,e.height)/3,M=e.width/2+Math.cos(r)*w,I=e.height/2+Math.sin(r)*w;t.beginPath(),t.arc(M,I,h*5,0,Math.PI*2);const S=t.createRadialGradient(M,I,0,M,I,h*5);S.addColorStop(0,`hsla(${c}, 100%, 50%, 1)`),S.addColorStop(1,`hsla(${c}, 100%, 50%, 0)`),t.fillStyle=S,t.fill()}}else if(d==="3d spectrum"){v.getByteFrequencyData(b),t.fillStyle="rgba(0, 0, 0, 0.2)",t.fillRect(0,0,e.width,e.height);const l=e.width/L*2.5,i=2,c=e.height/2,h=300;for(let r=0;r<L;r++){const w=b[r]/255,M=w*c,I=r/L,S=h/(h+I*e.height),k=e.width/2+(r-L/2)*(l+i)*S,R=e.height/2+e.height/4*S;t.fillStyle=`hsla(${270+w*60}, 100%, 50%, ${S})`,t.fillRect(k,R,l*S,-M*S)}}else if(d==="energy field"){v.getByteFrequencyData(b),t.fillStyle="rgba(0, 0, 0, 0.1)",t.fillRect(0,0,e.width,e.height);const l=e.width/2,i=e.height/2,c=Date.now()*.001;for(let h=0;h<L;h++){const r=b[h]/255,w=h/L*Math.PI*2,I=Math.min(e.width,e.height)/4+r*50+Math.sin(c+h*.2)*20,S=l+Math.cos(w)*I,k=i+Math.sin(w)*I,R=l+Math.cos(w+.1)*(I+r*30),W=i+Math.sin(w+.1)*(I+r*30);t.beginPath(),t.moveTo(S,k),t.lineTo(R,W);const _=t.createLinearGradient(S,k,R,W);_.addColorStop(0,`hsla(${270+r*60}, 100%, 50%, ${r})`),_.addColorStop(1,`hsla(${270+r*60}, 100%, 50%, 0)`),t.strokeStyle=_,t.lineWidth=2+r*3,t.stroke()}}}le();const ce=n("button",{class:"fullscreen-toggle",title:"Toggle Fullscreen"},"⛶"),Y=n("div",{class:"fullscreen-overlay"}),X=n("div",{class:"song-display"}),Z=n("div",{class:"time-display"}),ee=n("button",{class:"exit-fullscreen"},"×"),Ce=n("style",{},`
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @keyframes fadeOut {
        from {
            opacity: 1;
            transform: translateY(0);
        }
        to {
            opacity: 0;
            transform: translateY(10px);
        }
    }

    .fullscreen-toggle {
        position: fixed;
        top: 20px;
        right: 20px;
        background: rgba(255, 255, 255, 0.1);
        border: none;
        color: white;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        cursor: pointer;
        font-size: 20px;
        z-index: 1000000000;
        transition: all 0.3s ease;
        opacity: 0;
        pointer-events: none;
        backdrop-filter: blur(5px);
    }

    #sound-visualizer:hover ~ .fullscreen-toggle,
    .fullscreen-toggle:hover {
        opacity: 1;
        pointer-events: auto;
        animation: fadeIn 0.3s ease forwards;
    }

    .fullscreen-toggle:not(:hover) {
        animation: fadeOut 0.3s ease forwards;
    }

    .fullscreen-toggle:hover {
        background: rgba(255, 255, 255, 0.2);
        transform: scale(1.1);
    }

    #sound-visualizer-container.hidden {
        display: none !important;
    }

    #sound-visualizer.fullscreen {
        position: fixed !important;
        top: 0 !important;
        left: 0 !important;
        width: 100vw !important;
        height: 100vh !important;
        z-index: 9998 !important;
        background: black;
    }

    /* Styles for true fullscreen */
    :fullscreen #sound-visualizer.fullscreen {
        width: 100% !important;
        height: 100% !important;
    }

    :-webkit-full-screen #sound-visualizer.fullscreen {
        width: 100% !important;
        height: 100% !important;
    }

    .fullscreen-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 9999;
        pointer-events: none;
        transition: opacity 0.3s ease;
    }

    .fullscreen-overlay.active {
        display: block;
        animation: fadeIn 0.3s ease forwards;
    }

    .fullscreen-overlay:not(.active) {
        animation: fadeOut 0.3s ease forwards;
    }

    .song-display {
        position: absolute;
        left: 40px;
        bottom: 40px;
        color: white;
        font-family: 'SF Pro Display', -apple-system, BlinkMacSystemFont, sans-serif;
        text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        z-index: 1000000001;

    }

    .song-display, .time-display {

        transition: opacity 0.3s ease !important; /* Add transition */
    }

    .song-display .title {
        font-size: 32px;
        font-weight: 600;
        margin-bottom: 8px;
        background: linear-gradient(45deg, #fff, #9141FF);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        max-width: 600px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .song-display .time {
        font-size: 20px;
        opacity: 0.9;
        color: #fff;
    }

    .time-display {
        position: absolute;
        right: 40px;
        bottom: 40px;
        font-size: 48px;
        font-weight: 700;
        color: white;
        text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        font-family: 'SF Pro Display', -apple-system, BlinkMacSystemFont, sans-serif;
        background: linear-gradient(45deg, #fff, #9141FF);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        z-index: 1000000001;
     
    }

    .exit-fullscreen {
        position: absolute;
        top: 20px;
        right: 20px;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        border: none;
        background: rgba(255, 255, 255, 0.1);
        color: white;
        font-size: 24px;
        cursor: pointer;
        pointer-events: auto;
        transition: all 0.3s ease;
        backdrop-filter: blur(5px);
        z-index: 1000000001;
        opacity: 0;
    }

    .fullscreen-overlay:hover .exit-fullscreen {
        opacity: 1;
        animation: fadeIn 0.3s ease forwards;
    }

    .exit-fullscreen:hover {
        background: rgba(255, 255, 255, 0.2);
        transform: scale(1.1);
    }

    /* Add background gradient for better text visibility */
    .fullscreen-overlay::after {
        content: '';
        position: fixed;
        left: 0;
        right: 0;
        bottom: 0;
        height: 200px;
        background: linear-gradient(transparent, rgba(0,0,0,0.5));
        pointer-events: none;
        z-index: 9998;
        animation: fadeIn 0.5s ease forwards;
    }

    /* Updated Lyrics styles */
    /* Replace the existing lyrics styles with these */
    .fullscreen-lyrics {
        position: fixed;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
        z-index: 1000000001;
        width: 100%;
        pointer-events: none;
        transition: opacity 0.8s ease;
        opacity: 1;
        max-width: 90%;
    }
    
    .fullscreen-lyrics .caption-visual-line {
        opacity: 0;
        transform: translateY(20px);
        margin: 16px 0; /* Increased margin for better line spacing */
        transition: all 0.8s ease;
    }
    
    .fullscreen-lyrics .ytp-caption-segment {
        background: rgba(0, 0, 0, 0.85) !important; /* Darker background for AMOLED */
        font-size: 32px !important; /* Larger font size */
        font-weight: 700 !important; /* Bolder text */
        padding: 12px 24px !important; /* More padding */
        border-radius: 12px;
        backdrop-filter: blur(10px);
        letter-spacing: 0.02em; /* Improved text tracking */
        line-height: 1.4 !important; /* Better line height */
        font-family: 'SF Pro Display', -apple-system, BlinkMacSystemFont, sans-serif !important;
        text-shadow: 0 0 20px rgba(255, 255, 255, 0.2) !important;
        box-shadow: 0 4px 30px rgba(0, 0, 0, 0.3);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: #ffffff !important;
        animation: glowText 2s ease-in-out infinite;
    }
    
    @keyframes glowText {
        0%, 100% {
            text-shadow: 0 0 20px rgba(255, 255, 255, 0.2),
                         0 0 40px rgba(145, 65, 255, 0.1);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.3),
                        0 0 20px rgba(145, 65, 255, 0.1);
        }
        50% {
            text-shadow: 0 0 30px rgba(255, 255, 255, 0.3),
                         0 0 60px rgba(145, 65, 255, 0.2);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.3),
                        0 0 30px rgba(145, 65, 255, 0.2);
        }
    }
    
    /* Enhanced animations */
    @keyframes lyricsIn {
        0% {
            opacity: 0;
            transform: translateY(30px) scale(0.95);
        }
        100% {
            opacity: 1;
            transform: translateY(0) scale(1);
        }
    }
    
    @keyframes lyricsOut {
        0% {
            opacity: 1;
            transform: translateY(0) scale(1);
        }
        100% {
            opacity: 0;
            transform: translateY(-30px) scale(0.95);
        }
    }
    
    .fullscreen-lyrics.active .caption-visual-line {
        animation: lyricsIn 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    }
    
    .fullscreen-lyrics.active .caption-visual-line:nth-child(2) {
        animation-delay: 0.4s;
    }
    
    .fullscreen-lyrics.fade-out {
        opacity: 1;
    }
    
    .fullscreen-lyrics.hidden {
        opacity: 0;
        transition: opacity 1.2s ease;
    }
    
    /* Add a gradient overlay for better text contrast */
    .fullscreen-lyrics::before {
        content: '';
        position: absolute;
        top: -100px;
        left: -100px;
        right: -100px;
        bottom: -100px;
        background: radial-gradient(
            circle at center,
            transparent 0%,
            rgba(0, 0, 0, 0.3) 100%
        );
        pointer-events: none;
        z-index: -1;
    }
`);document.head.appendChild(Ce),s.appendChild(ce),document.body.appendChild(Y),Y.appendChild(X),Y.appendChild(Z),Y.appendChild(ee);const O=n("div",{class:"fullscreen-lyrics"});Y.appendChild(O);function de(){if(!K)return;const o=document.querySelector(".captions-text");if(o){const d=o.cloneNode(!0);O.innerHTML!==d.innerHTML&&(O.classList.remove("hidden"),O.innerHTML=d.innerHTML,O.classList.remove("active"),O.offsetWidth,O.classList.add("active"),clearTimeout(ne),ne=setTimeout(()=>{O.classList.add("hidden")},5e3))}}function pe(){var i;if(!K)return;const o=document.querySelector("video");if(!o)return;const d=((i=document.querySelector(".ytp-title-link"))==null?void 0:i.textContent)||"Unknown Track",y=ue(o.currentTime),B=ue(o.duration);X.innerHTML=`
        <div class="title">${d}</div>
        <div class="time">${y} / ${B}</div>
    `;const l=new Date;Z.textContent=l.toLocaleTimeString("en-US",{hour:"2-digit",minute:"2-digit",hour12:!0})}function ue(o){const d=Math.floor(o/60),y=Math.floor(o%60);return`${d}:${y.toString().padStart(2,"0")}`}let K=!1,he;function Ee(){A.trackEvent("FULLSCREEN",{action:"enter"}),K=!0,e.classList.add("fullscreen"),Y.classList.add("active"),s.classList.add("hidden"),document.body.appendChild(e),document.documentElement.requestFullscreen?document.documentElement.requestFullscreen():document.documentElement.webkitRequestFullscreen?document.documentElement.webkitRequestFullscreen():document.documentElement.msRequestFullscreen&&document.documentElement.msRequestFullscreen(),e.width=window.screen.width,e.height=window.screen.height,he=setInterval(()=>{pe(),de()},100),pe(),de()}function ae(){A.trackEvent("FULLSCREEN",{action:"exit"}),K=!1,e.classList.remove("fullscreen"),Y.classList.remove("active"),s.classList.remove("hidden"),document.exitFullscreen?document.exitFullscreen():document.webkitExitFullscreen?document.webkitExitFullscreen():document.msExitFullscreen&&document.msExitFullscreen(),s.insertBefore(e,s.firstChild),e.width=320,e.height=120,clearInterval(he)}ce.addEventListener("click",Ee),ee.addEventListener("click",ae),document.addEventListener("fullscreenchange",te),document.addEventListener("webkitfullscreenchange",te),document.addEventListener("mozfullscreenchange",te),document.addEventListener("MSFullscreenChange",te);function te(){!document.fullscreenElement&&!document.webkitFullscreenElement&&!document.mozFullScreenElement&&!document.msFullscreenElement&&ae()}window.addEventListener("resize",()=>{K&&(e.width=window.screen.width,e.height=window.screen.height)}),document.addEventListener("keydown",o=>{o.key==="Escape"&&K&&ae()});let ge,ne;document.addEventListener("mousemove",()=>{K&&(Y.style.opacity="1",X.style.opacity="1",Z.style.opacity="1",ee.style.opacity="1",O.classList.remove("hidden"),O.classList.remove("fade-out"),clearTimeout(ge),clearTimeout(ne),ge=setTimeout(()=>{X.style.opacity="0",Z.style.opacity="0",ee.style.opacity="0",Y.style.opacity="0"},3e3),ne=setTimeout(()=>{O.classList.add("hidden")},5e3))}),F.forEach(o=>{document.getElementById(o.id).addEventListener("input",d=>{A.trackEvent("EQ_ADJUSTMENT",{frequency:o.frequency,value:d.target.value});const y=j.find(B=>B.frequency.value===o.frequency);y&&(y.gain.value=parseFloat(d.target.value))})});function Le(o){A.trackEvent("PRESET_USE",{preset:o});const y={Rock:{low:6,bass:8,mid:-2,high:3,treble:4},Jazz:{low:-4,bass:-2,mid:5,high:6,treble:3},Pop:{low:4,bass:6,mid:2,high:5,treble:6},Classical:{low:-5,bass:-3,mid:4,high:7,treble:4},Metal:{low:6,bass:8,mid:-5,high:3,treble:2},"Hip-Hop":{low:4,bass:8,mid:2,high:3,treble:1}}[o]||{};Object.keys(y).forEach(B=>{const l=F.find(i=>i.label.toLowerCase()===B);if(l){const i=document.getElementById(l.id);if(i){i.value=y[B];const c=j.find(h=>h.frequency.value===l.frequency);c&&(c.gain.value=y[B])}}})}u.addEventListener("change",o=>{A.trackEvent("VISUALIZER_CHANGE",{type:o.target.value})})}const ve="1.6.0",ye={async checkForUpdates(){try{console.log("Checking for updates...");const p=await(await fetch("https://visualizer.pockethost.io/api/collections/versions/records?sort=-releaseDate&perPage=1")).json();if(p.items.length>0){const s=p.items[0];console.log("Current version:",ve),console.log("Latest version:",s.version),this.isNewerVersion(ve,s.version)&&this.showUpdatePopup(s)}}catch(a){console.error("Error checking for updates:",a)}},isNewerVersion(a,p){const s=a.split(".").map(Number),e=p.split(".").map(Number);for(let u=0;u<3;u++){if(e[u]>s[u])return!0;if(e[u]<s[u])return!1}return!1},showUpdatePopup(a){const p=document.createElement("div");p.style.cssText=`
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 999999999;
        `;const s=p.attachShadow({mode:"open"}),e=document.createElement("div");e.className="update-popup",e.innerHTML=`
            <div class="update-content">
                <div class="update-header">
                    <div class="update-header-left">
                        <h2>🎉 New Update Available!</h2>
                        <span class="version-tag">v${a.version}</span>
                    </div>
                    <button class="close-update" aria-label="Close">
                        <svg width="24" height="24" viewBox="0 0 24 24">
                            <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
                        </svg>
                    </button>
                </div>
                <div class="update-body">
                    <div class="changelog">
                        <div class="changelog-content">${a.changelog}</div>
                    </div>
                    ${a.isRequired?'<div class="required-update">⚠️ This update is required to continue using the app</div>':""}
                </div>
                <div class="update-footer">
                    <button class="update-now">
                        <span class="button-icon">⭐</span>
                        Update Now
                    </button>
                    ${a.isRequired?"":`
                        <button class="update-later">
                            <span class="button-icon">⏰</span>
                            Remind Me Later
                        </button>
                    `}
                </div>
            </div>
        `;const u=document.createElement("style");u.textContent=`
            .update-popup {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0,0,0,0.85);
                backdrop-filter: blur(8px);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 99999999;
                animation: fadeIn 0.3s ease;
                padding: 20px;
                pointer-events: auto;
            }

            .update-content {
                background: linear-gradient(145deg, #1a1a1a, #2a2a2a);
                border-radius: 16px;
                padding: 24px;
                width: 90%;
                max-width: 480px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.4);
                border: 1px solid rgba(255,255,255,0.1);
                transform: translateY(0);
                animation: slideUp 0.4s ease;
                pointer-events: auto;
            }

            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }

            @keyframes fadeOut {
                from { opacity: 1; }
                to { opacity: 0; }
            }

            @keyframes slideUp {
                from { 
                    opacity: 0;
                    transform: translateY(20px);
                }
                to { 
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            .update-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 24px;
            }

            .update-header-left {
                display: flex;
                align-items: center;
                gap: 12px;
            }

            .update-header h2 {
                margin: 0;
                color: #fff;
                font-size: 24px;
                font-weight: 600;
            }

            .version-tag {
                background: rgba(145, 65, 255, 0.2);
                color: #9141FF;
                padding: 4px 8px;
                border-radius: 6px;
                font-size: 14px;
                font-weight: 500;
            }

            .close-update {
                background: rgba(255,255,255,0.1);
                border: none;
                color: #fff;
                width: 32px;
                height: 32px;
                border-radius: 50%;
                cursor: pointer;
                padding: 0;
                display: flex;
                align-items: center;
                justify-content: center;
                transition: all 0.2s ease;
                pointer-events: auto;
            }

            .close-update:hover {
                background: rgba(255,255,255,0.2);
                transform: rotate(90deg);
            }

            .close-update svg {
                fill: currentColor;
                width: 20px;
                height: 20px;
            }

            .changelog {
                background: rgba(255,255,255,0.05);
                padding: 20px;
                border-radius: 12px;
                color: #fff;
                margin-bottom: 24px;
                max-height: 240px;
                overflow-y: auto;
                border: 1px solid rgba(255,255,255,0.1);
            }

            .changelog-content {
                white-space: pre-line;
                line-height: 1.6;
            }

            .required-update {
                background: rgba(255, 68, 68, 0.1);
                color: #ff4444;
                padding: 12px 16px;
                border-radius: 8px;
                margin: 16px 0;
                font-weight: 500;
                border: 1px solid rgba(255, 68, 68, 0.2);
            }

            .update-footer {
                display: flex;
                gap: 12px;
                justify-content: flex-end;
            }

            .update-footer button {
                padding: 12px 20px;
                border-radius: 8px;
                border: none;
                cursor: pointer;
                font-size: 15px;
                font-weight: 500;
                display: flex;
                align-items: center;
                gap: 8px;
                transition: all 0.3s ease;
                pointer-events: auto;
            }

            .update-now {
                background: linear-gradient(45deg, #9141FF, #A474FF);
                color: #fff;
            }

            .update-later {
                background: rgba(255,255,255,0.1);
                color: #fff;
            }

            .update-footer button:hover {
                transform: translateY(-2px);
                box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            }

            .update-now:hover {
                background: linear-gradient(45deg, #A474FF, #B797FF);
            }

            .button-icon {
                font-size: 16px;
            }

            .fade-out {
                animation: fadeOut 0.3s ease forwards;
            }
        `,s.appendChild(u),s.appendChild(e),document.body.appendChild(p);const x=()=>{e.style.animation="fadeOut 0.3s ease forwards",setTimeout(()=>p.remove(),300)},F=s.querySelector(".close-update"),P=s.querySelector(".update-now"),D=s.querySelector(".update-later");F.addEventListener("click",x),P.addEventListener("click",()=>{window.open(a.downloadUrl,"_blank"),a.isRequired||x()}),D&&D.addEventListener("click",x),e.addEventListener("click",C=>{C.target===e&&!a.isRequired&&x()})}};function ze(){const a="lastUpdateCheck",s=Number(localStorage.getItem(a))||0,e=Date.now();e-s>=864e5&&(ye.checkForUpdates(),localStorage.setItem(a,e.toString())),setInterval(()=>{ye.checkForUpdates(),localStorage.setItem(a,Date.now().toString())},864e5)}async function xe(){try{console.log("Initializing..."),await Ie(),console.log("YouTube UI loaded"),await A.trackEvent("SESSION_START",{referrer:document.referrer,userAgent:navigator.userAgent,screenSize:{width:window.screen.width,height:window.screen.height}}),Fe(),ze()}catch(a){console.error("Init error:",a),A.trackEvent("ERROR",{type:"INIT_ERROR",message:a.message,stack:a.stack})}}let be=location.href;new MutationObserver(()=>{location.href!==be&&(be=location.href,setTimeout(async()=>await xe(),2e3))}).observe(document,{subtree:!0,childList:!0});window.addEventListener("load",xe);window.addEventListener("error",a=>{var p;A.trackEvent("ERROR",{type:"RUNTIME_ERROR",message:a.message,stack:(p=a.error)==null?void 0:p.stack,lineNumber:a.lineno,fileName:a.filename})});
//# sourceMappingURL=content.js-95083144.js.map
